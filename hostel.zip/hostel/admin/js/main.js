 $(document).ready(function () {
	var blockstudentlink=$(".blockstudent")
 	$(".ts-sidebar-menu li a").each(function () {
 		if ($(this).next().length > 0) {
 			$(this).addClass("parent");
 		};
 	})
 	var menux = $('.ts-sidebar-menu li a.parent');
 	$('<div class="more"><i class="fa fa-angle-down"></i></div>').insertBefore(menux);
 	$('.more').click(function () {
 		$(this).parent('li').toggleClass('open');
 	});
	$('.parent').click(function (e) {
		e.preventDefault();
 		$(this).parent('li').toggleClass('open');
 	});
 	$('.menu-btn').click(function () {
 		$('nav.ts-sidebar').toggleClass('menu-open');
 	});
	 
	 
	 $('#zctb').DataTable();
	 
	 
	 $("#input-43").fileinput({
		showPreview: false,
		allowedFileExtensions: ["zip", "rar", "gz", "tgz"],
		elErrorContainer: "#errorBlock43"
		// you can configure `msgErrorClass` and `msgInvalidFileExtension` as well
	});

	blockstudentlink.on("click",function(e){
		e.preventDefault()
		id=$(this).attr("data-id")
		console.log(id)
		// bootbox to ask for reason to block
		bootbox.prompt({
			title: "Please select the reason for <strong>Blocking the student</strong>",
			inputType: 'select',
			value: ['1','3'],
			inputOptions: [
				{
					text: 'Choose one...',
					value: '',
				},
				{
					text: 'Indiscipline',
					value: 'indiscipline',
				},
				{
					text: 'Out of Session',
					value: 'outofsession',
				},
				{
					text: 'Pregnancy',
					value: 'pregnancy',
				}
			],
			callback: function (result) {
				//console.log(result);
				if(result !== null ){
					// block the student
					reason=result
					window.location.href="manage-students.php?block=1&id="+id+"&reason="+reason
				}
			}
		});
	})
	
 });
